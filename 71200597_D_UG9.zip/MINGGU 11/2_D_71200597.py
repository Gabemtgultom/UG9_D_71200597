a = float(input("\nMasukan alas atap  : "))
t = float(input("Masukkan tinggi atap: "))
t2 = float(input("Masukkan tinggi tembok "))
luas = 0.5*a*t

print("\nLuas Segitiga  = %0.2f" % luas)