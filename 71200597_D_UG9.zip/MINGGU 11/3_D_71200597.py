nama = input("Masukkan nama Anda :")
matkul = input("Masukkan mata kuliah :")
Grup = input("Masukkan grup : ")

pisah = nama.split(" ")
depan = pisah [0]
belakang = pisah [1]
print("Haloo!", belakang, ",", depan)
print(depan, "tergabung dalam kelas",  matkul, "pada grup" , Grup)