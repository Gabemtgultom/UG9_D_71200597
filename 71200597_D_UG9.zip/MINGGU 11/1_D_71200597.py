phi = 3.14
jariJari = float(input("Masukkan jari-jari : "))
Luas = phi*jariJari*jariJari
print("" + str(Luas))