jarak = input("Masukkan kecepatan tempuh :")
waktu = input("Masukkan waktu yang diperlukan :")
waktu = jarak / waktu
print("Waktu yang diperlukan ", waktu, "jam")